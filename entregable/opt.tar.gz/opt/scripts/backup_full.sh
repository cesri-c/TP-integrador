#!/bin/bash

# backup_full.sh - Script de backup con validación y formato estándar

function mostrar_ayuda() {
  echo "Uso: $0 <origen> <destino>"
  echo "Ejemplo: $0 /var/log /backup_dir"
  echo "Crea un backup tipo log_bkp_YYYYMMDD.tar.gz"
}

# Opción de ayuda
if [[ "$1" == "-h" || "$1" == "--help" ]]; then
  mostrar_ayuda
  exit 0
fi

# Validación de parámetros
if [[ -z "$1" || -z "$2" ]]; then
  echo "Error: faltan argumentos."
  mostrar_ayuda
  exit 1
fi

ORIGEN="$1"
DESTINO="$2"

# Validación de directorios
if [[ ! -d "$ORIGEN" ]]; then
  echo "Error: el directorio origen no existe: $ORIGEN"
  exit 2
fi

if [[ ! -d "$DESTINO" ]]; then
  echo " Error: el directorio destino no existe: $DESTINO"
  exit 3
fi

# Fecha en formato ANSI
FECHA=$(date +%Y%m%d)

# Nombre de archivo con prefijo estándar
if [[ "$ORIGEN" == "/var/log" ]]; then
  PREFIJO="log"
elif [[ "$ORIGEN" == "/www_dir" ]]; then
  PREFIJO="www"
else
  PREFIJO=$(basename "$ORIGEN" | tr -d '/')
fi

ARCHIVO="${DESTINO}/${PREFIJO}_bkp_${FECHA}.tar.gz"
#crear backup sin incluir rutas abasolutas
tar -czf "$ARCHIVO" -c "$ORIGEN" .

#mensaje y log opcional 
if [[$?/ -eq 0 ]]; then
  echo "Backup creado: $ARCHIVO"
  echo "$(date): Backup exitoso → $ARCHIVO" >> /var/log/backup_manual.log
else
  echo "Error al crear el backup"
  exit 4
fi
	
